<?php
/**
 * Template for the React Form application
 */

get_header(); ?>

<div class="react-form-container">
    <?php echo do_shortcode('[react_form_app]'); ?>
</div>

<?php get_footer(); ?>
