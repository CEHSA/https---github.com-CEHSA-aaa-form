<?php
/**
 * Plugin Name: React Form Integration
 * Description: Integrates React form application with WordPress
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 */

defined('ABSPATH') or die('Direct access not allowed');

class ReactFormIntegration {
    private $plugin_path;
    private $plugin_url;
    private $assets_dir = 'form-assets';

    public function __construct() {
        $this->plugin_path = plugin_dir_path(__FILE__);
        $this->plugin_url = plugin_dir_url(__FILE__);

        // Initialize hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('init', array($this, 'register_form_page'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_react_assets'));
        add_filter('template_include', array($this, 'load_react_template'));
        
        // Register activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));

        // Add REST API endpoints for form handling
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }

    public function activate_plugin() {
        // Create the form page if it doesn't exist
        $page = get_page_by_path('form');
        if (!$page) {
            wp_insert_post(array(
                'post_title' => 'Application Form',
                'post_name' => 'form',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => '[react_form_app]'
            ));
        }

        // Create assets directory if it doesn't exist
        $assets_path = $this->plugin_path . $this->assets_dir;
        if (!file_exists($assets_path)) {
            mkdir($assets_path, 0755, true);
        }

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    public function deactivate_plugin() {
        // Optionally remove the form page
        $page = get_page_by_path('form');
        if ($page) {
            wp_delete_post($page->ID, true);
        }

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    public function add_admin_menu() {
        add_menu_page(
            'React Form Settings',
            'React Form',
            'manage_options',
            'react-form-settings',
            array($this, 'render_admin_page'),
            'dashicons-feedback'
        );
    }

    public function render_admin_page() {
        include($this->plugin_path . 'admin/settings-page.php');
    }

    public function register_form_page() {
        add_shortcode('react_form_app', array($this, 'render_react_app'));
    }

    public function render_react_app() {
        return '<div id="root"></div>';
    }

    public function enqueue_react_assets() {
        if (is_page('form')) {
            // Enqueue React app assets
            $asset_manifest = $this->get_asset_manifest();
            
            if ($asset_manifest) {
                // Enqueue main JS bundle
                if (isset($asset_manifest['index.js'])) {
                    wp_enqueue_script(
                        'react-form-app',
                        $this->plugin_url . $this->assets_dir . '/' . $asset_manifest['index.js'],
                        array(),
                        '1.0.0',
                        true
                    );
                }

                // Enqueue CSS
                if (isset($asset_manifest['index.css'])) {
                    wp_enqueue_style(
                        'react-form-styles',
                        $this->plugin_url . $this->assets_dir . '/' . $asset_manifest['index.css'],
                        array(),
                        '1.0.0'
                    );
                }

                // Add environment variables
                wp_localize_script('react-form-app', 'wpEnv', array(
                    'siteUrl' => get_site_url(),
                    'apiUrl' => rest_url('react-form/v1'),
                    'nonce' => wp_create_nonce('wp_rest')
                ));
            }
        }
    }

    private function get_asset_manifest() {
        $manifest_path = $this->plugin_path . $this->assets_dir . '/manifest.json';
        if (file_exists($manifest_path)) {
            return json_decode(file_get_contents($manifest_path), true);
        }
        return null;
    }

    public function load_react_template($template) {
        if (is_page('form')) {
            $custom_template = $this->plugin_path . 'templates/react-template.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }
        return $template;
    }

    public function register_rest_routes() {
        register_rest_route('react-form/v1', '/settings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_settings'),
            'permission_callback' => function () {
                return current_user_can('manage_options');
            }
        ));

        // Add payment notification endpoint
        register_rest_route('react-form/v1', '/payment/notify', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_payment_notification'),
            'permission_callback' => '__return_true'
        ));
    }

    public function get_settings() {
        return rest_ensure_response(array(
            'ozowSiteCode' => get_option('react_form_ozow_site_code'),
            'ozowIsTest' => get_option('react_form_ozow_is_test', 'true')
        ));
    }

    public function handle_payment_notification($request) {
        $params = $request->get_params();
        
        // Log payment notification
        error_log('Payment notification received: ' . print_r($params, true));
        
        // Process payment notification
        // Add your payment processing logic here
        
        return rest_ensure_response(array(
            'status' => 'success',
            'message' => 'Notification received'
        ));
    }
}

// Initialize the plugin
$react_form_integration = new ReactFormIntegration();
