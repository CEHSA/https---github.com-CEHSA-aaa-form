<?php
// Prevent direct access
defined('ABSPATH') or die('Direct access not allowed');

// Save settings if form is submitted
if (isset($_POST['react_form_settings_submit'])) {
    check_admin_referer('react_form_settings_nonce');
    
    update_option('react_form_ozow_site_code', sanitize_text_field($_POST['ozow_site_code']));
    update_option('react_form_ozow_is_test', isset($_POST['ozow_is_test']) ? 'true' : 'false');
    
    echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
}

// Get current settings
$ozow_site_code = get_option('react_form_ozow_site_code', '');
$ozow_is_test = get_option('react_form_ozow_is_test', 'true') === 'true';
?>

<div class="wrap">
    <h1>React Form Settings</h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('react_form_settings_nonce'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="ozow_site_code">Ozow Site Code</label>
                </th>
                <td>
                    <input type="text" 
                           id="ozow_site_code" 
                           name="ozow_site_code" 
                           value="<?php echo esc_attr($ozow_site_code); ?>" 
                           class="regular-text">
                </td>
            </tr>
            
            <tr>
                <th scope="row">Test Mode</th>
                <td>
                    <label>
                        <input type="checkbox" 
                               name="ozow_is_test" 
                               <?php checked($ozow_is_test); ?>>
                        Enable test mode
                    </label>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" 
                   name="react_form_settings_submit" 
                   class="button button-primary" 
                   value="Save Settings">
        </p>
    </form>

    <hr>

    <h2>Deploy React App</h2>
    <p>Upload your React app build files here:</p>
    
    <form method="post" enctype="multipart/form-data">
        <?php wp_nonce_field('react_form_upload_nonce'); ?>
        <input type="file" name="react_build_zip" accept=".zip">
        <p class="submit">
            <input type="submit" 
                   name="react_form_upload_submit" 
                   class="button button-secondary" 
                   value="Upload and Deploy">
        </p>
    </form>

    <div class="react-form-instructions">
        <h3>Instructions</h3>
        <ol>
            <li>Build your React app using <code>npm run build</code> or <code>yarn build</code></li>
            <li>Zip the contents of your <code>dist</code> directory</li>
            <li>Upload the zip file using the form above</li>
            <li>The plugin will automatically extract and deploy your React app</li>
        </ol>
    </div>
</div>

<style>
.react-form-instructions {
    margin-top: 30px;
    padding: 20px;
    background: #fff;
    border-left: 4px solid #2271b1;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.react-form-instructions code {
    background: #f0f0f1;
    padding: 2px 6px;
    border-radius: 3px;
}
</style>
