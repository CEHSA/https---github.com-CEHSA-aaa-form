jQuery(document).ready(function($) {
    // CORS headers for AJAX requests
    $.ajaxSetup({
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-WP-Nonce', reactFormAdmin.nonce);
        },
        xhrFields: {
            withCredentials: true
        },
        crossDomain: true
    });

    // API Status check
    function checkApiStatus() {
        $.ajax({
            url: reactFormAdmin.apiUrl + '/health-check',
            method: 'GET',
            success: function(response) {
                $('.api-status').removeClass('status-error').addClass('status-ok');
                $('.api-status').html('<span class="status-indicator"></span>Connected');
            },
            error: function(xhr, status, error) {
                $('.api-status').removeClass('status-ok').addClass('status-error');
                $('.api-status').html('<span class="status-indicator"></span>Connection Error');
            }
        });
    }

    // Initialize API status check
    if ($('.api-status').length) {
        checkApiStatus();
        // Refresh status every 30 seconds
        setInterval(checkApiStatus, 30000);
    }

    // Save settings
    $('#react-form-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            ozow: {
                site_code: $('input[name="ozow_site_code"]').val(),
                api_key: $('input[name="ozow_api_key"]').val(),
                private_key: $('input[name="ozow_private_key"]').val(),
                is_test: $('input[name="ozow_test_mode"]').is(':checked')
            }
        };

        $.ajax({
            url: reactFormAdmin.apiUrl + '/settings',
            method: 'POST',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function(response) {
                addNotice('Settings saved successfully.', 'success');
            },
            error: function(xhr, status, error) {
                addNotice('Error saving settings: ' + error, 'error');
            }
        });
    });

    // Helper function to add admin notices
    function addNotice(message, type) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap h1').after(notice);
        
        // Make notices dismissible
        notice.find('button.notice-dismiss').on('click', function() {
            notice.remove();
        });

        // Auto-remove after 5 seconds
        setTimeout(function() {
            notice.fadeOut(function() {
                notice.remove();
            });
        }, 5000);
    }

    // Handle file browser sorting
    $('.file-browser th').on('click', function() {
        const table = $(this).parents('table').eq(0);
        const rows = table.find('tr:gt(0)').toArray().sort(comparer($(this).index()));
        this.asc = !this.asc;
        if (!this.asc) {
            rows.reverse();
        }
        for (let i = 0; i < rows.length; i++) {
            table.append(rows[i]);
        }
    });

    function comparer(index) {
        return function(a, b) {
            const valA = getCellValue(a, index);
            const valB = getCellValue(b, index);
            return $.isNumeric(valA) && $.isNumeric(valB) ?
                valA - valB : valA.localeCompare(valB);
        };
    }

    function getCellValue(row, index) {
        return $(row).children('td').eq(index).text();
    }
});